---
title: Reading List
subtitle: A list of books I am currently reading
layout: "page"
icon: fa-book
order: 3
---

I love books! Here are some I'm reading now:

1. Michael Law and Amy Collins: *Getting to Know ArcGIS Desktop, fifth edition*
2. ESRI: *The ArcGIS Book, second edition*

---