---
title: LIFE
author: Kemisola Adeniyi
layout: post
---

WHAT IS LIFE?

Life is fickle, life is short.
Losing a dear one hurts terribly.
One who has never experienced one cannot truly understand.
It makes me wonder, it drives many thoughts and questions.

What is there to this life?
Is it the achievements and the love?
Or the struggles and the pain?
Okay, perhaps a mixture of both I would say.

A minute we are here and the next we are gone.
Then it becomes too late to realize we should have lived better.
Better in what sense?
Live freely, holding no grudge.

People will hurt you, they will disrespect you.
Some will honour you and cherish you.
Embrace both, but keep the latter closer.
It is all for a while, it is life, Live it.

Smile through the pain, no matter how long it takes.
I know it can be tough, I understand it is really difficult.
I have been there many times.
It is however needful to note that we are here only for a short time.

I have lost parents, I have lost friends.
I have even lost people I never met physically.
I say lost because they were rare gems and an embodiment of grace.
Life will however always happen, be prepared!